﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilestoneProjectCST117__InventoryList
{
    class Inventory
    {
       // public void Add(List<Product> lst, Product)


    }
}
