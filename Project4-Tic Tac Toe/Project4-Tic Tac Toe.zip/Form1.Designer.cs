﻿namespace Project4_Tic_Tac_Toe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn00 = new System.Windows.Forms.Button();
            this.LblTicTacToe = new System.Windows.Forms.Label();
            this.Btn01 = new System.Windows.Forms.Button();
            this.Btn02 = new System.Windows.Forms.Button();
            this.Btn10 = new System.Windows.Forms.Button();
            this.Btn11 = new System.Windows.Forms.Button();
            this.Btn12 = new System.Windows.Forms.Button();
            this.Btn20 = new System.Windows.Forms.Button();
            this.Btn21 = new System.Windows.Forms.Button();
            this.Btn22 = new System.Windows.Forms.Button();
            this.BtnNewGame = new System.Windows.Forms.Button();
            this.BtnReset = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.LblXWon = new System.Windows.Forms.Label();
            this.LblOWon = new System.Windows.Forms.Label();
            this.LblTie = new System.Windows.Forms.Label();
            this.TbXWon = new System.Windows.Forms.TextBox();
            this.TBOWon = new System.Windows.Forms.TextBox();
            this.TbDrawGame = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Btn00
            // 
            this.Btn00.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn00.Location = new System.Drawing.Point(23, 56);
            this.Btn00.Name = "Btn00";
            this.Btn00.Size = new System.Drawing.Size(134, 111);
            this.Btn00.TabIndex = 0;
            this.Btn00.UseVisualStyleBackColor = true;
            this.Btn00.Click += new System.EventHandler(this.buttonClick);
            // 
            // LblTicTacToe
            // 
            this.LblTicTacToe.AutoSize = true;
            this.LblTicTacToe.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTicTacToe.Location = new System.Drawing.Point(234, 9);
            this.LblTicTacToe.Name = "LblTicTacToe";
            this.LblTicTacToe.Size = new System.Drawing.Size(254, 31);
            this.LblTicTacToe.TabIndex = 1;
            this.LblTicTacToe.Text = "Tic Tac Toe Game";
            // 
            // Btn01
            // 
            this.Btn01.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn01.Location = new System.Drawing.Point(163, 56);
            this.Btn01.Name = "Btn01";
            this.Btn01.Size = new System.Drawing.Size(134, 111);
            this.Btn01.TabIndex = 2;
            this.Btn01.UseVisualStyleBackColor = true;
            this.Btn01.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn02
            // 
            this.Btn02.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn02.Location = new System.Drawing.Point(303, 56);
            this.Btn02.Name = "Btn02";
            this.Btn02.Size = new System.Drawing.Size(134, 111);
            this.Btn02.TabIndex = 3;
            this.Btn02.UseVisualStyleBackColor = true;
            this.Btn02.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn10
            // 
            this.Btn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn10.Location = new System.Drawing.Point(23, 173);
            this.Btn10.Name = "Btn10";
            this.Btn10.Size = new System.Drawing.Size(134, 111);
            this.Btn10.TabIndex = 4;
            this.Btn10.UseVisualStyleBackColor = true;
            this.Btn10.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn11
            // 
            this.Btn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn11.Location = new System.Drawing.Point(163, 173);
            this.Btn11.Name = "Btn11";
            this.Btn11.Size = new System.Drawing.Size(134, 111);
            this.Btn11.TabIndex = 5;
            this.Btn11.UseVisualStyleBackColor = true;
            this.Btn11.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn12
            // 
            this.Btn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn12.Location = new System.Drawing.Point(303, 173);
            this.Btn12.Name = "Btn12";
            this.Btn12.Size = new System.Drawing.Size(134, 111);
            this.Btn12.TabIndex = 6;
            this.Btn12.UseVisualStyleBackColor = true;
            this.Btn12.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn20
            // 
            this.Btn20.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn20.Location = new System.Drawing.Point(23, 290);
            this.Btn20.Name = "Btn20";
            this.Btn20.Size = new System.Drawing.Size(134, 111);
            this.Btn20.TabIndex = 7;
            this.Btn20.UseVisualStyleBackColor = true;
            this.Btn20.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn21
            // 
            this.Btn21.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn21.Location = new System.Drawing.Point(163, 290);
            this.Btn21.Name = "Btn21";
            this.Btn21.Size = new System.Drawing.Size(134, 111);
            this.Btn21.TabIndex = 8;
            this.Btn21.UseVisualStyleBackColor = true;
            this.Btn21.Click += new System.EventHandler(this.buttonClick);
            // 
            // Btn22
            // 
            this.Btn22.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn22.Location = new System.Drawing.Point(303, 290);
            this.Btn22.Name = "Btn22";
            this.Btn22.Size = new System.Drawing.Size(134, 111);
            this.Btn22.TabIndex = 9;
            this.Btn22.UseVisualStyleBackColor = true;
            this.Btn22.Click += new System.EventHandler(this.buttonClick);
            // 
            // BtnNewGame
            // 
            this.BtnNewGame.BackColor = System.Drawing.Color.Navy;
            this.BtnNewGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNewGame.ForeColor = System.Drawing.Color.White;
            this.BtnNewGame.Location = new System.Drawing.Point(108, 407);
            this.BtnNewGame.Name = "BtnNewGame";
            this.BtnNewGame.Size = new System.Drawing.Size(110, 32);
            this.BtnNewGame.TabIndex = 10;
            this.BtnNewGame.Text = "New Game";
            this.BtnNewGame.UseVisualStyleBackColor = false;
            this.BtnNewGame.Click += new System.EventHandler(this.BtnNewGame_Click);
            // 
            // BtnReset
            // 
            this.BtnReset.BackColor = System.Drawing.Color.Olive;
            this.BtnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnReset.ForeColor = System.Drawing.Color.White;
            this.BtnReset.Location = new System.Drawing.Point(240, 407);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(110, 32);
            this.BtnReset.TabIndex = 11;
            this.BtnReset.Text = "Reset";
            this.BtnReset.UseVisualStyleBackColor = false;
            this.BtnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.Black;
            this.BtnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(460, 407);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(110, 32);
            this.BtnExit.TabIndex = 12;
            this.BtnExit.Text = "Exit";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // LblXWon
            // 
            this.LblXWon.AutoSize = true;
            this.LblXWon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblXWon.Location = new System.Drawing.Point(457, 105);
            this.LblXWon.Name = "LblXWon";
            this.LblXWon.Size = new System.Drawing.Size(63, 20);
            this.LblXWon.TabIndex = 13;
            this.LblXWon.Text = "X won:";
            // 
            // LblOWon
            // 
            this.LblOWon.AutoSize = true;
            this.LblOWon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblOWon.Location = new System.Drawing.Point(456, 217);
            this.LblOWon.Name = "LblOWon";
            this.LblOWon.Size = new System.Drawing.Size(68, 20);
            this.LblOWon.TabIndex = 14;
            this.LblOWon.Text = "O Won:";
            // 
            // LblTie
            // 
            this.LblTie.AutoSize = true;
            this.LblTie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTie.Location = new System.Drawing.Point(443, 334);
            this.LblTie.Name = "LblTie";
            this.LblTie.Size = new System.Drawing.Size(91, 20);
            this.LblTie.TabIndex = 15;
            this.LblTie.Text = "Tie Game:";
            // 
            // TbXWon
            // 
            this.TbXWon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbXWon.Location = new System.Drawing.Point(540, 102);
            this.TbXWon.Name = "TbXWon";
            this.TbXWon.ReadOnly = true;
            this.TbXWon.Size = new System.Drawing.Size(100, 26);
            this.TbXWon.TabIndex = 16;
            // 
            // TBOWon
            // 
            this.TBOWon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBOWon.Location = new System.Drawing.Point(540, 214);
            this.TBOWon.Name = "TBOWon";
            this.TBOWon.ReadOnly = true;
            this.TBOWon.Size = new System.Drawing.Size(100, 26);
            this.TBOWon.TabIndex = 17;
            // 
            // TbDrawGame
            // 
            this.TbDrawGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbDrawGame.Location = new System.Drawing.Point(540, 331);
            this.TbDrawGame.Name = "TbDrawGame";
            this.TbDrawGame.ReadOnly = true;
            this.TbDrawGame.Size = new System.Drawing.Size(100, 26);
            this.TbDrawGame.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 463);
            this.Controls.Add(this.TbDrawGame);
            this.Controls.Add(this.TBOWon);
            this.Controls.Add(this.TbXWon);
            this.Controls.Add(this.LblTie);
            this.Controls.Add(this.LblOWon);
            this.Controls.Add(this.LblXWon);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnReset);
            this.Controls.Add(this.BtnNewGame);
            this.Controls.Add(this.Btn22);
            this.Controls.Add(this.Btn21);
            this.Controls.Add(this.Btn20);
            this.Controls.Add(this.Btn12);
            this.Controls.Add(this.Btn11);
            this.Controls.Add(this.Btn10);
            this.Controls.Add(this.Btn02);
            this.Controls.Add(this.Btn01);
            this.Controls.Add(this.LblTicTacToe);
            this.Controls.Add(this.Btn00);
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn00;
        private System.Windows.Forms.Label LblTicTacToe;
        private System.Windows.Forms.Button Btn01;
        private System.Windows.Forms.Button Btn02;
        private System.Windows.Forms.Button Btn10;
        private System.Windows.Forms.Button Btn11;
        private System.Windows.Forms.Button Btn12;
        private System.Windows.Forms.Button Btn20;
        private System.Windows.Forms.Button Btn21;
        private System.Windows.Forms.Button Btn22;
        private System.Windows.Forms.Button BtnNewGame;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Label LblXWon;
        private System.Windows.Forms.Label LblOWon;
        private System.Windows.Forms.Label LblTie;
        private System.Windows.Forms.TextBox TbXWon;
        private System.Windows.Forms.TextBox TBOWon;
        private System.Windows.Forms.TextBox TbDrawGame;
    }
}

